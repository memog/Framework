//
//  MemogFramework.h
//  MemogFramework
//
//  Created by Guillermo Garcia on 1/15/19.
//  Copyright © 2019 Guillermo Garcia. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MemogFramework.
FOUNDATION_EXPORT double MemogFrameworkVersionNumber;

//! Project version string for MemogFramework.
FOUNDATION_EXPORT const unsigned char MemogFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MemogFramework/PublicHeader.h>


