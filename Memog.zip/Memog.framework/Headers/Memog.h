//
//  Memog.h
//  Memog
//
//  Created by Guillermo Garcia on 1/17/19.
//  Copyright © 2019 Guillermo Garcia. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Memog.
FOUNDATION_EXPORT double MemogVersionNumber;

//! Project version string for Memog.
FOUNDATION_EXPORT const unsigned char MemogVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Memog/PublicHeader.h>


